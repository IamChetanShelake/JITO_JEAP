@extends('admin.layouts.master')

@section('title', 'Bank Details Management - JitoJeap Admin')

@section('styles')
    <style>
        :root {
            --primary-green: #4CAF50;
            --primary-purple: #393185;
            --primary-blue: #2196F3;
            --primary-yellow: #FFC107;
            --primary-red: #f44336;
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
            --bg-light: #f8f9fa;
            --border-color: #e9ecef;
        }

        .page-header {
            margin-bottom: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        @media (min-width: 768px) {
            .page-header {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
            }
        }

        .page-title-section {
            display: flex;
            flex-direction: column;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-purple);
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
        }

        @media (min-width: 768px) {
            .page-title {
                font-size: 1.75rem;
            }
        }

        .page-subtitle {
            color: var(--text-light);
            font-size: 0.9rem;
        }

        @media (min-width: 768px) {
            .page-subtitle {
                font-size: 0.95rem;
            }
        }

        .add-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 0.6rem 1.2rem;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            box-shadow: 0 2px 8px rgba(57, 49, 133, 0.3);
            width: 100%;
            font-size: 0.9rem;
        }

        @media (min-width: 768px) {
            .add-btn {
                width: auto;
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
            }
        }

        .add-btn:hover {
            background-color: #4a40a8;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(57, 49, 133, 0.4);
        }

        .add-btn i {
            font-size: 0.9rem;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .table-container {
            position: relative;
            width: 100%;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            scrollbar-color: var(--primary-green) transparent;
        }

        .table-responsive::-webkit-scrollbar {
            height: 6px;
        }

        .table-responsive::-webkit-scrollbar-thumb {
            background-color: var(--primary-purple);
            border-radius: 3px;
        }

        .table {
            width: 100%;
            min-width: 800px;
            margin-bottom: 0;
            color: var(--text-dark);
        }

        .table thead th {
            background-color: var(--bg-light);
            color: var(--text-light);
            font-weight: 500;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border-color);
            padding: 1rem;
            vertical-align: middle;
            white-space: nowrap;
            position: sticky;
            top: 0;
        }

        .table tbody td {
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
            color: #555;
            font-size: 0.9rem;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
            transition: background-color 0.2s ease;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 0.1rem;
            transition: all 0.2s ease;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .action-btn.view-btn {
            background-color: #e3f2fd;
            color: var(--primary-blue);
        }

        .action-btn.view-btn:hover {
            background-color: var(--primary-blue);
            color: white;
        }

        .action-btn.edit-btn {
            background-color: #fff8e1;
            color: var(--primary-yellow);
        }

        .action-btn.edit-btn:hover {
            background-color: var(--primary-yellow);
            color: white;
        }

        .action-btn.delete-btn {
            background-color: #ffebee;
            color: var(--primary-red);
        }

        .action-btn.delete-btn:hover {
            background-color: var(--primary-red);
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #999;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #e0e0e0;
        }

        . {
            display: flex;
            justify-content: center;
            gap: 0.2rem;
        }

        .badge {
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
            font-weight: 500;
        }

        .badge-light {
            background: #f8f9fa;
            color: #333;
            border: 1px solid #e0e0e0;
        }

        /* Mobile specific styles */
        @media (max-width: 767.98px) {
            .table-container {
                border-radius: 10px;
                overflow: hidden;
            }

            .table-responsive {
                border-radius: 10px;
            }

            .table {
                min-width: 100%;
            }

            .table-responsive {
                -webkit-mask-image: linear-gradient(to right, transparent 0%, black 5%, black 95%, transparent 100%);
                mask-image: linear-gradient(to right, transparent 0%, black 5%, black 95%, transparent 100%);
            }

            .scroll-hint {
                position: absolute;
                right: 0;
                top: 50%;
                transform: translateY(-50%);
                background: rgba(255, 255, 255, 0.9);
                padding: 0.5rem;
                border-radius: 50% 0 0 50%;
                box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
                z-index: 10;
                display: none;
            }

            .table-responsive:hover .scroll-hint {
                display: block;
            }
        }

        @media (min-width: 768px) {
            .scroll-hint {
                display: none !important;
            }
        }
    </style>
@endsection

@section('content')
    <div class="page-header">
        <div class="page-title-section">
            <h1 class="page-title">
                <i class="fas fa-university" style="color: var(--primary-purple); margin-right: 0.5rem;"></i>
                Jito Jeap Bank Details
            </h1>
            <p class="page-subtitle">Manage bank account details</p>
        </div>
        <a href="{{ route('admin.jito-jeap-banks.create') }}" class="add-btn">
            <i class="fas fa-plus"></i> Add Bank Details
        </a>
    </div>

    <div class="card">
        <div class="table-container">
            <div class="table-responsive">
                <div class="scroll-hint">
                    <i class="fas fa-chevron-right" style="color: var(--primary-purple);"></i>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 5%;">Seq</th>
                            <th style="width: 20%;">Account Name</th>
                            <th style="width: 20%;">Bank Name</th>
                            <th style="width: 15%;">Account Type</th>
                            <th style="width: 20%;">Account Number</th>
                            <th style="width: 10%;">IFSC Code</th>
                            <th style="width: 10%;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($jitoJeapBanks as $index => $bank)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td><span class="badge badge-light">{{ $bank->account_name }}</span></td>
                                <td>{{ $bank->bank_name }}</td>
                                <td>{{ $bank->account_type }}</td>
                                <td>{{ $bank->account_number }}</td>
                                <td>{{ $bank->ifsc_code }}</td>
                                <td class="">
                                    <a href="{{ route('admin.jito-jeap-banks.edit', $bank) }}" class="action-btn edit-btn"
                                        title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('admin.jito-jeap-banks.destroy', $bank) }}" method="POST"
                                        style="display: inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="action-btn delete-btn" title="Delete"
                                            onclick="return confirm('Are you sure you want to delete this bank details?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <p>No bank details found. Click "Add Bank Details" to get started.</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
