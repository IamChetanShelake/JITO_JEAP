@extends('user.layout.master')
@section('step')
    <button class="btn btn-purple me-2" style="background-color: #393185; color: white;">Step 2 of
        7</button>
@endsection
@section('content')
    <style>
        .modern-form-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
            border: none;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #393185;
            margin-bottom: 8px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 60px;
            height: 2px;
            background: #393185;
        }

        .photo-upload-box {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
            margin-bottom: 10px;
        }

        .photo-label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: #333;
        }

        .upload-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 5px 15px;
            border-radius: 3px;
            cursor: pointer;
            display: inline-block;
        }

        .upload-btn:hover {
            background: #0056b3;
        }

        .upload-icon {
            margin-right: 5px;
        }

        .nav.nav-tabs .nav-link {
            color: #4C4C4C;
            font-size: 16px;
            font-weight: 600;
            background: none;
            border: none;
            padding-bottom: 8px;
            position: relative;

        }

        .nav.nav-tabs .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50%;
            height: 3.5px;
            margin-left: 15px;
            background: #4C4C4C;
        }

        .qualification-group {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid #e9ecef;
        }

        .qualification-title {
            font-weight: 600;
            color: #393185;
            margin-bottom: 10px;
        }

        .year-select {
            width: 120px;
        }

        .section-divider {
            height: 1px;
            background: #e9ecef;
            margin: 30px 0;
        }

        .form-control-sm {
            border-radius: 15px;
        }

        label {
            color: #4C4C4C;
        }
    </style>



    <!-- Main Content -->
    <div class="col-lg-9 main-content">
        <!-- Hold Remark Alert -->
        @if ($educationDetail && $educationDetail->submit_status === 'resubmit' && $educationDetail->admin_remark)
            <div class="alert alert-warning alert-dismissible fade show" role="alert"
                style="background-color: #fff3cd; border-color: #ffeaa7; color: #856404; border-radius: 8px; margin-bottom: 20px;">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div style="min-width: 0;">
                        <strong><i class="bi bi-exclamation-triangle-fill"></i> Hold Notice:</strong>
                        <p
                            style="margin: 8px 0 4px 0; font-size: 14px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                            {{ trim(preg_replace('/\s+/', ' ', strip_tags($educationDetail->admin_remark))) }}
                        </p>
                        <button type="button" class="btn btn-link p-0" data-bs-toggle="modal"
                            data-bs-target="#holdRemarkModal">
                            View More
                        </button>
                    </div>
                    <button type="button" class="btn-close ms-2 flex-shrink-0" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            </div>

            <div class="modal fade" id="holdRemarkModal" tabindex="-1" aria-labelledby="holdRemarkModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="holdRemarkModalLabel">Hold Notice</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            {!! $educationDetail->admin_remark !!}
                        </div>
                    </div>
                </div>
            </div>
        @endif
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <form method="POST" action="{{ route('user.step2ug.store') }}" enctype="multipart/form-data"
                        novalidate>
                        @csrf
                        @if (session('success'))
                            <div class="alert alert-warning alert-dismissible fade show position-relative" role="alert"
                                id="successAlert">

                                {{ session('success') }}

                                <button type="button" class="close custom-close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif



                        <div class="row mb-3">
                            <div class="col-md-5 offset-md-1">

                                <select class="form-control" name="financial_asset_type" id="financial_asset_type"
                                    style="border:2px solid #393185;border-radius:15px;" readonly required>
                                    <option disabled
                                        {{ (old('financial_asset_type') ?: $user->financial_asset_type ?? '') ? '' : 'selected' }}
                                        hidden>Financial Asst Type <span style="color: red;">*</span></option>
                                    <option value="domestic"
                                        {{ (old('financial_asset_type') ?: $user->financial_asset_type ?? '') == 'domestic' ? 'selected' : '' }}
                                        hidden>
                                        Domestic</option>
                                    <option value="foreign_finance_assistant"
                                        {{ (old('financial_asset_type') ?: $user->financial_asset_type ?? '') == 'foreign_finance_assistant' ? 'selected' : '' }}
                                        hidden>
                                        Foreign Financial Assistance</option>
                                </select>
                                <small class="text-danger"
                                    id="financial_asset_type_error">{{ $errors->first('financial_asset_type') }}</small>
                            </div>
                            <div class="col-md-5">
                                <select class="form-control" name="financial_asset_for" id="financial_asset_for"
                                    style="border:2px solid #393185;border-radius:15px;" readonly required>
                                    <option disabled
                                        {{ (old('financial_asset_for') ?: $user->financial_asset_for ?? '') ? '' : 'selected' }}
                                        hidden>Financial Asst For *</option>
                                    <option value="graduation"
                                        {{ (old('financial_asset_for') ?: $user->financial_asset_for ?? '') == 'graduation' ? 'selected' : '' }}
                                        hidden>
                                        Graduation</option>
                                    <option value="post_graduation"
                                        {{ (old('financial_asset_for') ?: $user->financial_asset_for ?? '') == 'post_graduation' ? 'selected' : '' }}
                                        hidden>
                                        Post Graduation</option>
                                </select>
                                <small class="text-danger"
                                    id="financial_asset_for_error">{{ $errors->first('financial_asset_for') }}</small>
                            </div>
                        </div>
                        <div class="card form-card">
                            <div class="card-body">

                                <div class="step-card">
                                    <div class="card-icon">
                                        <i class="bi bi-mortarboard"></i>
                                    </div>
                                    <div>
                                        <h3 class="card-title">Education Details</h3>
                                        <p class="card-subtitle">Information about your educational background</p>
                                    </div>
                                </div>


                                <!-- Section 1: Your Financial Need Overview -->
                                <div class="education-section">
                                    <h4 class="title" style="color:#4C4C4C;font-size:18px;">Your Financial Need Overview
                                    </h4>

                                    <div class="row">
                                        <!-- Left Column -->
                                        <div class="col-md-6">
                                            
                                            <div class="form-group mb-3">
                                                <label for="university_name">University Name <span
                                                        style="color: red;">*</span></label>
                                                <select id="university_name" class="form-control"
                                                    name="university_name" required>
                                                    <option value="" disabled
                                                        {{ old('university_name', $educationDetail->university_name ?? '') ? '' : 'selected' }}>
                                                        Select University Name</option>
                                                    @foreach ($universities as $university)
                                                        <option value="{{ $university->university_name }}"
                                                            {{ (old('university_name') ?: $educationDetail->university_name ?? '') == $university->university_name ? 'selected' : '' }}>
                                                            {{ $university->university_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                <small class="text-danger"
                                                    id="university_name_error">{{ $errors->first('university_name') }}</small>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="college_name">College Name <span
                                                        style="color: red;">*</span></label>
                                                <select id="college_name" class="form-control"
                                                    name="college_name" required>
                                                    <option value="" disabled
                                                        {{ old('college_name', $educationDetail->college_name ?? '') ? '' : 'selected' }}>
                                                        Select College Name</option>
                                                    @foreach ($colleges as $college)
                                                        @php
                                                            $coursesData = is_array($college->courses) ? $college->courses : (is_string($college->courses) ? json_decode($college->courses, true) : []);
                                                        @endphp
                                                        <option value="{{ $college->college_name }}"
                                                            data-courses='{{ json_encode($coursesData) }}'
                                                            data-university="{{ $college->university_name }}"
                                                            {{ (old('college_name') ?: $educationDetail->college_name ?? '') == $college->college_name ? 'selected' : '' }}>
                                                            {{ $college->college_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                <small class="text-danger"
                                                    id="college_name_error">{{ $errors->first('college_name') }}</small>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="course_name">Course Name <span
                                                        style="color: red;">*</span></label>
                                                <select id="course_name" class="form-control"
                                                    name="course_name" required
                                                    data-existing-course="{{ $educationDetail->course_name ?? '' }}">
                                                    <option value=""
                                                        {{ empty(old('course_name')) && empty($educationDetail->course_name ?? '') ? 'selected' : '' }}
                                                        disabled>
                                                        Select Course Name</option>
                                                    @if($educationDetail && old('course_name', $educationDetail->course_name ?? ''))
                                                        <option value="{{ old('course_name', $educationDetail->course_name) }}" selected>
                                                            {{ old('course_name', $educationDetail->course_name) }}
                                                        </option>
                                                    @endif
                                                </select>
                                                <small class="text-danger"
                                                    id="course_name_error">{{ $errors->first('course_name') }}</small>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="country">Country Name <span
                                                        style="color: red;">*</span></label>
                                                <input type="text" id="country" class="form-control" name="country"
                                                    placeholder="Enter Country Name "
                                                    value="{{ old('country', $educationDetail->country ?? '') }}"
                                                    required>
                                                <small class="text-danger"
                                                    id="country_error">{{ $errors->first('country') }}</small>
                                            </div>

                                        </div>

                                        <!-- Right Column -->
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="city_name">City Name <span
                                                        style="color: red;">*</span></label>
                                                <input type="text" id="city_name" class="form-control"
                                                    name="city_name" placeholder="Enter City Name "
                                                    value="{{ old('city_name', $educationDetail->city_name ?? '') }}"
                                                    required>
                                                <small class="text-danger"
                                                    id="city_name_error">{{ $errors->first('city_name') }}</small>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="start_year">
                                                    Start Date <span style="color:red">*</span>
                                                </label>

                                                <input type="date" id="start_year" class="form-control"
                                                    name="start_year"
                                                    value="{{ old('start_year') ?: ($educationDetail && $educationDetail->start_year ? \Carbon\Carbon::parse($educationDetail->start_year)->format('Y-m-d') : '') }}"
                                                    min="1900-01-01"
                                                    max="{{ \Carbon\Carbon::now()->addYear()->format('Y-m-d') }}"
                                                    required>

                                                <small class="text-danger">{{ $errors->first('start_year') }}</small>
                                            </div>


                                            {{-- <div class="form-group mb-3">
                                                <label for="expected_year">Expected Year of Completion <span
                                                        style="color:red">*</span></label>
                                                <input type="month" id="expected_year" class="form-control"
                                                    name="expected_year"
                                                    value="{{ old('expected_year') ?: ($educationDetail && $educationDetail->expected_year ? \Carbon\Carbon::parse($educationDetail->expected_year)->format('Y-m') : '') }}"
                                                    min="{{ date('Y-m') }}" required oninput="validateExpectedYear()">
                                                <small id="expectedYearError" class="text-danger d-none">
                                                    Expected month must be after start month and within next 5 years
                                                </small>
                                            </div> --}}

                                            <div class="form-group mb-3">
                                                <label for="expected_year">
                                                    Expected Date of Completion <span style="color:red">*</span>
                                                </label>

                                                <input type="date" id="expected_year" class="form-control"
                                                    name="expected_year"
                                                    value="{{ old('expected_year') ?: ($educationDetail && $educationDetail->expected_year ? \Carbon\Carbon::parse($educationDetail->expected_year)->format('Y-m-d') : '') }}"
                                                    required>

                                                <small class="text-danger">{{ $errors->first('expected_year') }}</small>
                                            </div>




                                            <div class="form-group mb-3">
                                                <label for="nirf_ranking">NIRF Ranking</label>
                                                <input type="number" id="nirf_ranking" class="form-control"
                                                    name="nirf_ranking" placeholder=" Enter NIRF Ranking"
                                                    value="{{ old('nirf_ranking', $educationDetail->nirf_ranking ?? '') }}">
                                                <small class="text-danger"
                                                    id="nirf_ranking_error">{{ $errors->first('nirf_ranking') }}</small>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                                <!-- Section 2: Financial Summary Table -->
                                <div class="education-section">
                                    {{-- <h4 class="title" style="color:#4C4C4C;font-size:18px;">Financial Summary</h4> --}}

                                    <div class="table-responsive mt-4">
                                        <table class="table" id="yearWiseTable"
                                            style="background: white; border: none; border-collapse: collapse;">
                                            <thead style="background-color: #f8f9fa;">
                                                <tr style="border-bottom: 1px solid lightgray;">
                                                    <th class="text-center"
                                                        style="width: 80px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        Sr No</th>
                                                    <th class="text-center"
                                                        style="font-weight: 600; color: #4C4C4C; border: none;width: 25%;">
                                                        Group Name</th>
                                                    <th class="text-center"
                                                        style="width: 100px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        1 Year</th>
                                                    <th class="text-center"
                                                        style="width: 100px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        2 Year</th>
                                                    <th class="text-center"
                                                        style="width: 100px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        3 Year</th>
                                                    <th class="text-center"
                                                        style="width: 100px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        4 Year</th>
                                                    <th class="text-center"
                                                        style="width: 100px; font-weight: 600; color: #4C4C4C; border: none;">
                                                        5 Year</th>
                                                    <th class="text-center"
                                                        style="width: 120px; font-weight: 600; color: #393185; border: none;">
                                                        Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- Row 1: Tuition Fees -->
                                                <tr style="border-bottom: 1px solid lightgray;">
                                                    <td class="text-center" style="font-weight: 500; border: none;">1</td>
                                                    <td
                                                        style="font-weight: 500; border: none;width: 25%;text-align:center;">
                                                        <input type="text" class="form-control form-control-sm"
                                                            name="group_name_1" value="Tuition Fees" hidden>Tuition Fees
                                                    </td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_year1"
                                                            value="{{ old('group_1_year1') ?: $educationDetail->group_1_year1 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_year2"
                                                            value="{{ old('group_1_year2') ?: $educationDetail->group_1_year2 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_year3"
                                                            value="{{ old('group_1_year3') ?: $educationDetail->group_1_year3 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_year4"
                                                            value="{{ old('group_1_year4') ?: $educationDetail->group_1_year4 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_year5"
                                                            value="{{ old('group_1_year5') ?: $educationDetail->group_1_year5 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_1_total"
                                                            value="{{ old('group_1_total') ?: $educationDetail->group_1_total ?? '' }}"
                                                            placeholder="0" readonly></td>
                                                </tr>

                                                <!-- Row 2 -->
                                                <tr style="border-bottom: 1px solid lightgray;">
                                                    <td class="text-center" style="font-weight: 500; border: none;">2</td>
                                                    <td style="border: none;width: 25%;text-align:center;"><input
                                                            type="text" class="form-control form-control-sm"
                                                            name="group_name_2" value="Living Expenses" hidden>Living
                                                        Expenses
                                                    </td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_year1"
                                                            value="{{ old('group_2_year1') ?: $educationDetail->group_2_year1 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_year2"
                                                            value="{{ old('group_2_year2') ?: $educationDetail->group_2_year2 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_year3"
                                                            value="{{ old('group_2_year3') ?: $educationDetail->group_2_year3 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_year4"
                                                            value="{{ old('group_2_year4') ?: $educationDetail->group_2_year4 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_year5"
                                                            value="{{ old('group_2_year5') ?: $educationDetail->group_2_year5 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_2_total"
                                                            value="{{ old('group_2_total') ?: $educationDetail->group_2_total ?? '' }}"
                                                            placeholder="0" readonly>
                                                    </td>
                                                </tr>

                                                <!-- Row 3 -->
                                                <tr style="border-bottom: 1px solid lightgray;">
                                                    <td class="text-center" style="font-weight: 500; border: none;">3</td>
                                                    <td style="border: none;width: 25%;text-align:center;"><input
                                                            type="text" class="form-control form-control-sm"
                                                            name="group_name_3" value="Other Expenses"
                                                            placeholder="Enter Group Name" hidden>Other Expenses</td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_year1"
                                                            value="{{ old('group_3_year1') ?: $educationDetail->group_3_year1 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_year2"
                                                            value="{{ old('group_3_year2') ?: $educationDetail->group_3_year2 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_year3"
                                                            value="{{ old('group_3_year3') ?: $educationDetail->group_3_year3 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_year4"
                                                            value="{{ old('group_3_year4') ?: $educationDetail->group_3_year4 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_year5"
                                                            value="{{ old('group_3_year5') ?: $educationDetail->group_3_year5 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_3_total"
                                                            value="{{ old('group_3_total') ?: $educationDetail->group_3_total ?? '' }}"
                                                            placeholder="0" readonly>
                                                    </td>
                                                </tr>

                                                <!-- Row 4 -->
                                                <tr>
                                                    <td class="text-center" style="font-weight: 500; border: none;">4</td>
                                                    <td style="border: none;width: 25%;text-align:center;"><input
                                                            type="text" class="form-control form-control-sm"
                                                            name="group_name_4" value="Total Expenses"
                                                            placeholder="Enter Group Name" hidden>Total Expenses</td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_year1"
                                                            value="{{ old('group_4_year1') ?: $educationDetail->group_4_year1 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_year2"
                                                            value="{{ old('group_4_year2') ?: $educationDetail->group_4_year2 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_year3"
                                                            value="{{ old('group_4_year3') ?: $educationDetail->group_4_year3 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_year4"
                                                            value="{{ old('group_4_year4') ?: $educationDetail->group_4_year4 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_year5"
                                                            value="{{ old('group_4_year5') ?: $educationDetail->group_4_year5 ?? '' }}"
                                                            placeholder="0"></td>
                                                    <td style="border: none;"><input type="number"
                                                            class="form-control form-control-sm" name="group_4_total"
                                                            value="{{ old('group_4_total') ?: $educationDetail->group_4_total ?? '' }}"
                                                            placeholder="0" readonly>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Error messages for table fields -->
                                    <div class="mb-3">
                                        <small class="text-danger" id="table_error" style="display: none;">Please fill
                                            all financial summary fields with values greater than 0.</small>
                                    </div>
                                </div>



                                <!-- Section Divider -->
                                <div class="section-divider"></div>

                                <!-- Section 4: School / 10th Grade Information -->
                                <div class="education-section">
                                    <h4 class="title" style="color:#4C4C4C;font-size:18px;">School / 10th Grade
                                        Information</h4>

                                    <div class="row">
                                        <!-- Left Column -->
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="school_name">School Name <span
                                                        style="color: red;">*</span></label>
                                                <input type="text" class="form-control" id="school_name"
                                                    name="school_name" placeholder="School Name "
                                                    value="{{ old('school_name') ?: $educationDetail->school_name ?? '' }}">
                                                <small class="text-danger"
                                                    id="school_name_error">{{ $errors->first('school_name') }}</small>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="school_board">Board <span style="color: red;">*</span></label>
                                                <input type="text" class="form-control" id="school_board"
                                                    name="school_board" placeholder="Board "
                                                    value="{{ old('school_board') ?: $educationDetail->school_board ?? '' }}">
                                                <small class="text-danger">{{ $errors->first('school_board') }}</small>
                                            </div>
                                            {{-- <div class="form-group mb-3">
                                                <label for="school_completion_year">Year of Completion <span
                                                        style="color: red;">*</span></label>
                                                <input type="month" class="form-control" id="school_completion_year"
                                                    name="school_completion_year" placeholder="Select Month and Year"
                                                    value="{{ old('school_completion_year') ?: ($educationDetail && $educationDetail->school_completion_year ? $educationDetail->\Carbon\Carbon::parse($educationDetail->school_completion_year)->format('Y-m') : '') }}">
                                                <small
                                                    class="text-danger">{{ $errors->first('school_completion_year') }}</small>
                                            </div> --}}
                                            <div class="form-group mb-3">
                                                <label for="school_completion_year">Year of Completion <span
                                                        style="color: red;">*</span></label>
                                                <input type="month" class="form-control" id="school_completion_year"
                                                    name="school_completion_year" placeholder="Select Month and Year"
                                                    value="{{ old('school_completion_year') ?: ($educationDetail && $educationDetail->school_completion_year ? \Carbon\Carbon::parse($educationDetail->school_completion_year)->format('Y-m') : '') }}"
                                                    max="{{ date('Y') - 1 }}-12" required>
                                                <small
                                                    class="text-danger">{{ $errors->first('school_completion_year') }}</small>
                                            </div>
                                        </div>

                                        <!-- Right Column -->
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="school_grade_system">Grade System <span
                                                        style="color: red;">*</span></label>
                                                <div>
                                                    {{-- <input type="radio" id="grade_percentage"
                                                        name="school_grade_system" value="percentage"
                                                        {{ old('school_grade_system', 'percentage') == 'percentage' ? 'checked' : '' }}> --}}
                                                    <input type="radio" id="grade_percentage"
                                                        name="school_grade_system" value="percentage"
                                                        {{ old('school_grade_system', $educationDetail->school_grade_system ?? '') == 'percentage' ? 'checked' : '' }}>



                                                    <label
                                                        for="grade_percentage">Percentage</label>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    {{-- <input type="radio" id="grade_cgpa" name="school_grade_system"
                                                        value="cgpa"
                                                        {{ old('school_grade_system') == 'cgpa' ? 'checked' : '' }}> --}}
                                                    <input type="radio" id="grade_cgpa" name="school_grade_system"
                                                        value="cgpa"
                                                        {{ old('school_grade_system', $educationDetail->school_grade_system ?? '') == 'cgpa' ? 'checked' : '' }}>
                                                    <label for="grade_cgpa">CGPA </label>
                                                </div>
                                            </div>

                                            <div id="percentage_fields"
                                                style="display: {{ old('school_grade_system', 'percentage') == 'percentage' ? 'block' : 'none' }};">
                                                <div class="row">
                                                    <div class="col-2 text-start">
                                                        <div class="form-group mb-3"><label for="10th_mark_obtained">Marks
                                                                obtained:</label></div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="form-group mb-3"><input class="form-control"
                                                                id="10th_mark_obtained" type="number"
                                                                name="10th_mark_obtained"
                                                                value="{{ old('10th_mark_obtained') ?: $educationDetail->{'10th_mark_obtained'} ?? '' }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-2 text-start">
                                                        <div class="form-group mb-3 text-end"><label
                                                                for="10th_mark_out_of">Out Of:</label></div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="form-group mb-3"><input class="form-control"
                                                                id="10th_mark_out_of" type="number"
                                                                name="10th_mark_out_of"
                                                                value="{{ old('10th_mark_out_of') ?: $educationDetail->{'10th_mark_out_of'} ?? '' }}">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group mb-3">
                                                    <label for="school_percentage">Percentage (%)</label>
                                                    <input type="text" class="form-control" id="school_percentage"
                                                        name="school_percentage" placeholder="Enter % "
                                                        value="{{ old('school_percentage') ?: $educationDetail->school_percentage ?? '' }}">
                                                    <small
                                                        class="text-danger">{{ $errors->first('school_percentage') }}</small>
                                                </div>
                                            </div>

                                            {{-- <div id="cgpa_fields"
                                                style="display: {{ old('school_grade_system') == 'cgpa' ? 'block' : 'none' }};">
                                                <div class="form-group mb-3">
                                                    <label for="school_CGPA">CGPA</label>
                                                    <input type="text" class="form-control" id="school_CGPA"
                                                        name="school_CGPA" placeholder="Enter CGPA"
                                                        value="{{ old('school_CGPA') ?: $educationDetail->school_CGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('school_CGPA') }}</small>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="school_SGPA">SGPA</label>
                                                    <input type="text" class="form-control" id="school_SGPA"
                                                        name="school_SGPA" placeholder="Enter SGPA"
                                                        value="{{ old('school_SGPA') ?: $educationDetail->school_SGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('school_SGPA') }}</small>
                                                </div>
                                            </div> --}}
                                            <div id="cgpa_fields"
                                                style="display: {{ old('school_grade_system') == 'cgpa' ? 'block' : 'none' }};">

                                                <!-- CGPA OUT OF -->
                                                <div class="form-group mb-3">
                                                    <label for="school_cgpa_out_of">CGPA Out Of</label>
                                                    <select class="form-control" id="school_cgpa_out_of"
                                                        name="school_cgpa_out_of">
                                                        <option value="">Select</option>
                                                        <option value="10"
                                                            {{ old('school_cgpa_out_of', $educationDetail->school_cgpa_out_of ?? '') == 10 ? 'selected' : '' }}>
                                                            10</option>
                                                        <option value="5"
                                                            {{ old('school_cgpa_out_of', $educationDetail->school_cgpa_out_of ?? '') == 5 ? 'selected' : '' }}>
                                                            5</option>
                                                    </select>
                                                    <small
                                                        class="text-danger">{{ $errors->first('school_cgpa_out_of') }}</small>
                                                </div>

                                                <!-- CGPA -->
                                                <div class="form-group mb-3">
                                                    <label for="school_CGPA">CGPA</label>
                                                    <input type="text" class="form-control" id="school_CGPA"
                                                        name="school_CGPA" placeholder="Enter CGPA"
                                                        value="{{ old('school_CGPA') ?: $educationDetail->school_CGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('school_CGPA') }}</small>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <!-- Section Divider -->
                                <div class="section-divider"></div>

                                <!-- Section 3: Junior College (12th Grade) -->
                                <div class="education-section">
                                    <h4 class="title" style="color:#4C4C4C;font-size:18px;">Junior College (12th Grade)
                                    </h4>

                                    <div class="row">
                                        <!-- Left Column -->
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="jc_college_name">College / Junior College Name <span
                                                        style="color: red;">*</span></label>
                                                <input type="text" class="form-control" id="jc_college_name"
                                                    name="jc_college_name" placeholder="College / Junior College Name "
                                                    value="{{ old('jc_college_name') ?: $educationDetail->jc_college_name ?? '' }}">
                                                <small class="text-danger">{{ $errors->first('jc_college_name') }}</small>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="jc_stream">Stream <span style="color: red;">*</span></label>
                                                <input type="text" class="form-control" id="jc_stream"
                                                    name="jc_stream" placeholder="Select Stream "
                                                    value="{{ old('jc_stream') ?: $educationDetail->jc_stream ?? '' }}">
                                                <small class="text-danger">{{ $errors->first('jc_stream') }}</small>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="jc_board">Board <span style="color: red;">*</span></label>
                                                <input type="text" class="form-control" id="jc_board"
                                                    name="jc_board" placeholder="Select Board "
                                                    value="{{ old('jc_board') ?: $educationDetail->jc_board ?? '' }}">
                                                <small class="text-danger">{{ $errors->first('jc_board') }}</small>
                                            </div>
                                            {{-- <div class="form-group mb-3">
                                                <label for="jc_completion_year">Year of Completion <span
                                                        style="color: red;">*</span></label>
                                                <input type="month" class="form-control" id="jc_completion_year"
                                                    name="jc_completion_year" placeholder="Select Month and Year"
                                                    value="{{ old('jc_completion_year') ?: ($educationDetail && $educationDetail->jc_completion_year ? $educationDetail->\Carbon\Carbon::parse($educationDetail->jc_completion_year)->format('Y-m') : '') }}">
                                                <small
                                                    class="text-danger">{{ $errors->first('jc_completion_year') }}</small>
                                            </div> --}}

                                            <div class="form-group mb-3">
                                                <label for="jc_completion_year">Year of Completion <span
                                                        style="color: red;">*</span></label>
                                                <input type="month" class="form-control" id="jc_completion_year"
                                                    name="jc_completion_year" placeholder="Select Month and Year"
                                                    value="{{ old('jc_completion_year') ?: ($educationDetail && $educationDetail->jc_completion_year ? \Carbon\Carbon::parse($educationDetail->jc_completion_year)->format('Y-m') : '') }}"
                                                    max="{{ date('Y') }}-12" required>
                                                <small
                                                    class="text-danger">{{ $errors->first('jc_completion_year') }}</small>
                                            </div>
                                        </div>

                                        <!-- Right Column -->
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="jc_grade_system">Grade System<span
                                                        style="color: red;">*</span></label>
                                                <div>
                                                    {{-- <input type="radio" id="jc_grade_percentage" name="jc_grade_system"
                                                        value="percentage"
                                                        {{ old('jc_grade_system', 'percentage') == 'percentage' ? 'checked' : '' }}>
                                                    <label
                                                        for="jc_grade_percentage">Percentage</label>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <input type="radio" id="jc_grade_cgpa" name="jc_grade_system"
                                                        value="cgpa"
                                                        {{ old('jc_grade_system') == 'cgpa' ? 'checked' : '' }}>
                                                    <label for="jc_grade_cgpa">CGPA or SGPA</label> --}}
                                                    <input type="radio" id="jc_grade_percentage" name="jc_grade_system"
                                                        value="percentage"
                                                        {{ old('jc_grade_system', $educationDetail->jc_grade_system ?? 'percentage') == 'percentage' ? 'checked' : '' }}>

                                                    <label
                                                        for="jc_grade_percentage">Percentage</label>&nbsp;&nbsp;&nbsp;&nbsp;

                                                    <input type="radio" id="jc_grade_cgpa" name="jc_grade_system"
                                                        value="cgpa"
                                                        {{ old('jc_grade_system', $educationDetail->jc_grade_system ?? '') == 'cgpa' ? 'checked' : '' }}>

                                                    <label for="jc_grade_cgpa">CGPA</label>

                                                </div>
                                            </div>

                                            <div id="jc_percentage_fields"
                                                style="display: {{ old('jc_grade_system', 'percentage') == 'percentage' ? 'block' : 'none' }};">
                                                <div class="row">
                                                    <div class="col-2 text-start">
                                                        <div class="form-group mb-3"><label for="12th_mark_obtained">Marks
                                                                obtained:</label></div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="form-group mb-3"><input class="form-control"
                                                                id="12th_mark_obtained" type="number"
                                                                name="12th_mark_obtained"
                                                                value="{{ old('12th_mark_obtained') ?: $educationDetail->{'12th_mark_obtained'} ?? '' }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-2">
                                                        <div class="form-group mb-3 text-start">
                                                            <label for="12th_mark_out_of">Out Of:</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="form-group mb-3">
                                                            <input class="form-control" id="12th_mark_out_of"
                                                                type="number" name="12th_mark_out_of"
                                                                value="{{ old('12th_mark_out_of') ?: $educationDetail->{'12th_mark_out_of'} ?? '' }}">
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="form-group mb-3">
                                                    <label for="jc_percentage">Percentage (%)</label>
                                                    <input type="text" class="form-control" id="jc_percentage"
                                                        name="jc_percentage" placeholder="Enter %"
                                                        value="{{ old('jc_percentage') ?: $educationDetail->jc_percentage ?? '' }}">
                                                    <small
                                                        class="text-danger">{{ $errors->first('jc_percentage') }}</small>
                                                </div>
                                            </div>

                                            {{-- <div id="jc_cgpa_fields"
                                                style="display: {{ old('jc_grade_system') == 'cgpa' ? 'block' : 'none' }};">
                                                <div class="form-group mb-3">
                                                    <label for="jc_CGPA">CGPA</label>
                                                    <input type="text" class="form-control" id="jc_CGPA"
                                                        name="jc_CGPA" placeholder="Enter CGPA"
                                                        value="{{ old('jc_CGPA') ?: $educationDetail->jc_CGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('jc_CGPA') }}</small>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="jc_SGPA">SGPA</label>
                                                    <input type="text" class="form-control" id="jc_SGPA"
                                                        name="jc_SGPA" placeholder="Enter SGPA"
                                                        value="{{ old('jc_SGPA') ?: $educationDetail->jc_SGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('jc_SGPA') }}</small>
                                                </div>
                                            </div> --}}


                                            <div id="jc_cgpa_fields"
                                                style="display: {{ old('jc_grade_system') == 'cgpa' ? 'block' : 'none' }};">

                                                <!-- CGPA OUT OF -->
                                                <div class="form-group mb-3">
                                                    <label for="jc_cgpa_out_of">CGPA Out Of</label>
                                                    <select class="form-control" id="jc_cgpa_out_of"
                                                        name="jc_cgpa_out_of">
                                                        <option value="">Select</option>
                                                        <option value="10"
                                                            {{ old('jc_cgpa_out_of', $educationDetail->jc_cgpa_out_of ?? '') == 10 ? 'selected' : '' }}>
                                                            10</option>
                                                        <option value="5"
                                                            {{ old('jc_cgpa_out_of', $educationDetail->jc_cgpa_out_of ?? '') == 5 ? 'selected' : '' }}>
                                                            5</option>
                                                    </select>
                                                    <small
                                                        class="text-danger">{{ $errors->first('jc_cgpa_out_of') }}</small>
                                                </div>

                                                <!-- CGPA -->
                                                <div class="form-group mb-3">
                                                    <label for="jc_CGPA">CGPA</label>
                                                    <input type="text" class="form-control" id="jc_CGPA"
                                                        name="jc_CGPA" placeholder="Enter CGPA"
                                                        value="{{ old('jc_CGPA') ?: $educationDetail->jc_CGPA ?? '' }}">
                                                    <small class="text-danger">{{ $errors->first('jc_CGPA') }}</small>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                </div>

                <div class="d-flex justify-content-between mt-4 mb-4">
                    <a href="{{ route('user.step1') }}" class="btn"
                        style="background:#988DFF1F;color:gray;border:1px solid lightgray;" id="prevBtn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                            stroke="gray" stroke-width="2" viewBox="0 0 24 24">
                            <path d="M15 18l-6-6 6-6" />
                        </svg>
                        Previous
                    </a>
                    @if ($educationDetail && $educationDetail->user->workflowStatus->apex_1_status == 'approved')
                        <button type="button" class="btn"
                            style="background:#F0FDF4;color:#009846;border:1px solid #009846" disabled>
                            <i class="bi bi-check-lg" style="color: green; font-size: 24px;"></i>
                            Approved
                        </button>
                    @elseif ($educationDetail && $educationDetail->submit_status == 'resubmit')
                        <button type="submit" class="btn" style="background:#F0FDF4;color:red;border:1px solid red">
                            <i class="bi bi-arrow-clockwise" style="color: red; font-size: 24px;"></i>
                            Resubmit 
                        </button>
                    @else
                        <button type="submit" class="btn" style="background:#393185;color:white;">Next Step <svg
                                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                                stroke="white" stroke-width="2" viewBox="0 0 24 24">
                                <path d="M9 6l6 6-6 6" />
                            </svg>
                        </button>
                    @endif
                </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to handle college selection and populate courses
            function handleCollegeChange() {
                const collegeSelect = document.getElementById('college_name');
                const courseSelect = document.getElementById('course_name');
                
                if (collegeSelect && courseSelect) {
                    collegeSelect.addEventListener('change', function() {
                        const selectedOption = this.options[this.selectedIndex];
                        const coursesData = selectedOption.getAttribute('data-courses');
                        
                        console.log('College changed, courses data:', coursesData);
                        
                        // Get existing course_name from the data attribute (set by server)
                        const existingCourseName = courseSelect.getAttribute('data-existing-course');
                        console.log('Existing course name:', existingCourseName);
                        
                        // Clear existing options
                        courseSelect.innerHTML = '<option value="" disabled selected>Select Course Name</option>';
                        
                        // Check if courses data exists and is not empty
                        if (coursesData && coursesData !== 'null' && coursesData !== '' && coursesData !== '[]' && coursesData !== '{}') {
                            try {
                                const coursesArray = JSON.parse(coursesData);
                                // Handle both array and object formats
                                const courses = Array.isArray(coursesArray) ? coursesArray : Object.values(coursesArray);
                                
                                if (courses && courses.length > 0) {
                                    courses.forEach(function(course) {
                                        if (course) {
                                            const option = document.createElement('option');
                                            option.value = course;
                                            option.textContent = course;
                                            // Check if this is the existing course
                                            if (existingCourseName && course === existingCourseName) {
                                                option.selected = true;
                                            }
                                            courseSelect.appendChild(option);
                                        }
                                    });
                                    console.log('Courses populated:', courses);
                                } else {
                                    // No courses available, allow manual entry
                                    courseSelect.innerHTML = '<option value="">Select Course Name</option>';
                                }
                            } catch (e) {
                                console.error('Error parsing courses:', e);
                                courseSelect.innerHTML = '<option value="">Select Course Name</option>';
                            }
                        } else {
                            // No courses data available, allow manual entry
                            courseSelect.innerHTML = '<option value="">Select Course Name</option>';
                            // If there's an existing course and no courses from college, add it as manual entry
                            if (existingCourseName) {
                                const option = document.createElement('option');
                                option.value = existingCourseName;
                                option.textContent = existingCourseName;
                                option.selected = true;
                                courseSelect.appendChild(option);
                            }
                        }
                    });
                    
                    if (collegeSelect.value) {
                        collegeSelect.dispatchEvent(new Event('change'));
                    }
                }
            }
            
            handleCollegeChange();
            
            // Function to toggle qualification fields


            // Function to toggle school grade fields
            /* ========== SCHOOL (10th) TOGGLE ========== */
            function toggleSchoolGradeFields() {
                const percentageRadio = document.getElementById('grade_percentage');
                const cgpaRadio = document.getElementById('grade_cgpa');
                const percentageFields = document.getElementById('percentage_fields');
                const cgpaFields = document.getElementById('cgpa_fields');

                if (!percentageRadio || !cgpaRadio) return;

                if (percentageRadio.checked) {
                    percentageFields.style.display = 'block';
                    cgpaFields.style.display = 'none';
                } else if (cgpaRadio.checked) {
                    percentageFields.style.display = 'none';
                    cgpaFields.style.display = 'block';
                }
            }



            document.getElementById('grade_percentage')?.addEventListener('change', toggleSchoolGradeFields);
            document.getElementById('grade_cgpa')?.addEventListener('change', toggleSchoolGradeFields);


            /* ========== JC (12th) TOGGLE ========== */
            function toggleJcGradeFields() {
                const percentageRadio = document.getElementById('jc_grade_percentage');
                const cgpaRadio = document.getElementById('jc_grade_cgpa');
                const percentageFields = document.getElementById('jc_percentage_fields');
                const cgpaFields = document.getElementById('jc_cgpa_fields');

                if (!percentageRadio || !cgpaRadio) return;

                if (percentageRadio.checked) {
                    percentageFields.style.display = 'block';
                    cgpaFields.style.display = 'none';
                } else if (cgpaRadio.checked) {
                    percentageFields.style.display = 'none';
                    cgpaFields.style.display = 'block';
                }
            }
            document.getElementById('jc_grade_percentage')?.addEventListener('change', toggleJcGradeFields);
            document.getElementById('jc_grade_cgpa')?.addEventListener('change', toggleJcGradeFields);




            // Function to calculate school percentage
            function calculateSchoolPercentage() {
                const obtained = parseFloat(document.getElementById('10th_mark_obtained').value) || 0;
                const outOf = parseFloat(document.getElementById('10th_mark_out_of').value) || 0;
                const percentageInput = document.getElementById('school_percentage');
                if (outOf > 0) {
                    const percentage = (obtained / outOf) * 100;
                    percentageInput.value = percentage.toFixed(2);
                } else {
                    percentageInput.value = '';
                }
            }

            // Event listeners for school marks inputs
            document.getElementById('10th_mark_obtained').addEventListener('input', calculateSchoolPercentage);
            document.getElementById('10th_mark_out_of').addEventListener('input', calculateSchoolPercentage);

            // Function to calculate jc percentage
            function calculateJcPercentage() {
                const obtained = parseFloat(document.getElementById('12th_mark_obtained').value) || 0;
                const outOf = parseFloat(document.getElementById('12th_mark_out_of').value) || 0;
                const percentageInput = document.getElementById('jc_percentage');
                if (outOf > 0) {
                    const percentage = (obtained / outOf) * 100;
                    percentageInput.value = percentage.toFixed(2);
                } else {
                    percentageInput.value = '';
                }
            }

            // Event listeners for jc marks inputs
            document.getElementById('12th_mark_obtained').addEventListener('input', calculateJcPercentage);
            document.getElementById('12th_mark_out_of').addEventListener('input', calculateJcPercentage);

            // Function to check if work experience data exists and show fields accordingly


            // Initialize on page load



            toggleSchoolGradeFields();
            toggleJcGradeFields();
        });
    </script>
    <script>
        const now = new Date();

        // current month
        const currentMonth = new Date(now.getFullYear(), now.getMonth(), 1);

        // start month limit = current + 4 months
        const maxStartMonth = new Date(now.getFullYear(), now.getMonth() + 4, 1);

        function parseMonth(value) {
            const [year, month] = value.split('-');
            return new Date(year, month - 1, 1);
        }

        function validateStartYear() {
            const input = document.getElementById('start_year');
            const error = document.getElementById('startYearError');

            if (!input.value) return;

            const selected = parseMonth(input.value);

            if (selected < currentMonth || selected > maxStartMonth) {
                input.classList.add('is-invalid');
                error.classList.remove('d-none');
                input.value = ''; // Clear invalid value
            } else {
                input.classList.remove('is-invalid');
                error.classList.add('d-none');
            }
        }

        // Prevent form submission if start year is invalid
        document.querySelector('form').addEventListener('submit', function(e) {
            const input = document.getElementById('start_year');
            const error = document.getElementById('startYearError');

            if (!input.value) {
                // Required field, but let HTML required handle it
                return;
            }

            const selected = parseMonth(input.value);

            if (selected > maxStartMonth) {
                e.preventDefault();
                input.classList.add('is-invalid');
                error.classList.remove('d-none');
                input.focus();
            }
        });

        function validateExpectedYear() {
            const input = document.getElementById('expected_year');
            const error = document.getElementById('expectedYearError');
            const startInput = document.getElementById('start_year');

            if (!input.value || !startInput.value) return;

            const expected = parseMonth(input.value);
            const start = parseMonth(startInput.value);

            // ✅ correct max = start + 5 years
            const maxExpectedFromStart = new Date(
                start.getFullYear() + 5,
                start.getMonth(),
                1
            );

            if (expected < start || expected > maxExpectedFromStart) {
                input.classList.add('is-invalid');
                error.classList.remove('d-none');
            } else {
                input.classList.remove('is-invalid');
                error.classList.add('d-none');
            }
        }

        // Function to populate table with saved data
        function populateTableWithSavedData() {
            const table = document.getElementById('yearWiseTable');
            if (!table) return;

            // Get saved data from PHP variables (passed from controller)
            const savedData = @json($educationDetail ?? null);

            if (!savedData) return;

            // Populate each row with saved data
            const groups = [{
                    id: 1,
                    name: 'group_1'
                },
                {
                    id: 2,
                    name: 'group_2'
                },
                {
                    id: 3,
                    name: 'group_3'
                },
                {
                    id: 4,
                    name: 'group_4'
                }
            ];

            groups.forEach(group => {
                // Populate year columns
                for (let year = 1; year <= 5; year++) {
                    const input = document.querySelector(`input[name="${group.name}_year${year}"]`);
                    if (input && savedData[`${group.name}_year${year}`]) {
                        input.value = savedData[`${group.name}_year${year}`];
                    }
                }

                // Populate total column
                const totalInput = document.querySelector(`input[name="${group.name}_total"]`);
                if (totalInput && savedData[`${group.name}_total`]) {
                    totalInput.value = savedData[`${group.name}_total`];
                }
            });
        }
    </script>

    <script>
        function parseMonth(value) {
            const [year, month] = value.split('-');
            return new Date(year, month - 1, 1);
        }

        function calculateYearDiff() {
            const startVal = document.getElementById('start_year').value;
            const endVal = document.getElementById('expected_year').value;

            if (!startVal || !endVal) return;

            const start = parseMonth(startVal);
            const end = parseMonth(endVal);

            let yearDiff = end.getFullYear() - start.getFullYear();

            // if end month < start month → reduce 1 year
            if (end.getMonth() < start.getMonth()) {
                yearDiff--;
            }

            if (yearDiff < 1) yearDiff = 1;
            if (yearDiff > 5) yearDiff = 5; // cap at 5 years

            generateTableColumns(yearDiff);
        }

        function generateTableColumns(years) {
            const table = document.getElementById('yearWiseTable');

            // ---- THEAD ----
            let thead = `
        <tr style="border-bottom:1px solid lightgray;">
            <th class="text-center">Sr No</th>
            <th class="text-center">Group Name</th>
    `;

            for (let i = 1; i <= years; i++) {
                thead += `<th class="text-center">${i} Year</th>`;
            }

            thead += `<th class="text-center">Total</th></tr>`;
            table.querySelector('thead').innerHTML = thead;

            // ---- TBODY ----
            const groups = [{
                    id: 1,
                    name: 'Tuition Fees'
                },
                {
                    id: 2,
                    name: 'Living Expenses'
                },
                {
                    id: 3,
                    name: 'Other Expenses'
                },
                {
                    id: 4,
                    name: 'Total Expenses'
                }
            ];

            let tbody = '';

            groups.forEach(group => {
                tbody += `
        <tr style="border-bottom:1px solid lightgray;">
            <td class="text-center">${group.id}</td>
            <td class="text-center">${group.name}</td>
        `;

                for (let y = 1; y <= years; y++) {
                    tbody += `
                <td>
                    <input type="number" class="form-control form-control-sm"
                        name="group_${group.id}_year${y}" placeholder="0">
                </td>
            `;
                }

                tbody += `
            <td>
                <input type="number" class="form-control form-control-sm"
                    name="group_${group.id}_total" placeholder="0" readonly>
            </td>
        </tr>`;
            });

            table.querySelector('tbody').innerHTML = tbody;
        }

        // trigger on change
        document.getElementById('start_year').addEventListener('change', calculateYearDiff);
        document.getElementById('expected_year').addEventListener('change', calculateYearDiff);

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            // If we have saved start and expected years, generate table accordingly
            const startYearInput = document.getElementById('start_year');
            const expectedYearInput = document.getElementById('expected_year');

            if (startYearInput.value && expectedYearInput.value) {
                calculateYearDiff();
            }

            // Populate table with saved data
            populateTableWithSavedData();
        });

        const selectedLoanCategory = @json($type ?? null);
        const enforceOneLakhCap = selectedLoanCategory === 'below';
        let hasShownTotalExpensesLimitModal = false;

        function showTotalExpensesErrorModal(totalExpenses) {
            const modalHtml = `
                <div class="modal fade" id="totalExpensesErrorModal" tabindex="-1" aria-labelledby="totalExpensesErrorModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content" style="border:2px solid #dc3545;">
                            <div class="modal-header" style="border-bottom:1px solid #dc3545; background-color: #dc3545; color: white;">
                                <h5 class="modal-title" id="totalExpensesErrorModalLabel" style="color: white;">Not Eligible</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                    aria-label="Close" onclick="closeTotalExpensesModal()"></button>
                            </div>
                            <div class="modal-body">
                                <p style="color: #dc3545; font-weight: 600; font-size: 16px;">
                                    Your Total Expenses (Rs. ${totalExpenses.toLocaleString()}) exceeds Rs. 1,00,000 (1 Lakh).<br><br>
                                    You are not eligible for this financial assistance program.<br><br>
                                    Please contact the administrator for more information.
                                </p>
                            </div>
                            <div class="modal-footer" style="border-top:1px solid #dc3545; display: flex; justify-content: space-between;">
                                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal"
                                    onclick="clearTableValuesAndCloseModal()" style="border-color: #dc3545; color: #dc3545;">Cancel</button>
                                <button type="button" class="btn btn-outline-primary" onclick="redirectToAbove1Lakh()" style="border-color: #007bff; color: #007bff;">Select Above 1 Lakh Application</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            const existingModal = document.getElementById('totalExpensesErrorModal');
            if (existingModal) {
                existingModal.remove();
            }

            document.body.insertAdjacentHTML('beforeend', modalHtml);
            const modalEl = document.getElementById('totalExpensesErrorModal');

            if (window.bootstrap && bootstrap.Modal) {
                const modal = new bootstrap.Modal(modalEl, {
                    backdrop: 'static',
                    keyboard: false
                });
                modal.show();
            }
        }

        function closeTotalExpensesModal() {
            const modalEl = document.getElementById('totalExpensesErrorModal');
            if (!modalEl) return;

            if (window.bootstrap && bootstrap.Modal) {
                const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modal.hide();
            }

            setTimeout(() => {
                const modalBackdrop = document.querySelector('.modal-backdrop');
                if (modalBackdrop) {
                    modalBackdrop.remove();
                }
                document.body.classList.remove('modal-open');
                document.body.style.paddingRight = '';

                if (modalEl.parentNode) {
                    modalEl.parentNode.removeChild(modalEl);
                }
                window.location.reload();
            }, 150);
        }

        function clearTableValuesAndCloseModal() {
            // Clear all input fields in the table
            const tableInputs = document.querySelectorAll('#yearWiseTable input[type="number"]');
            tableInputs.forEach(input => {
                input.value = '';
            });

            // Recalculate totals after clearing
            calculateTotalExpenses();

            closeTotalExpensesModal();
        }

        function clearTableValues() {
            // Clear all input fields in the table
            const tableInputs = document.querySelectorAll('#yearWiseTable input[type="number"]');
            tableInputs.forEach(input => {
                input.value = '';
            });

            // Recalculate totals after clearing
            calculateTotalExpenses();

            // Close the modal
            const modalEl = document.getElementById('totalExpensesErrorModal');
            if (modalEl && window.bootstrap && bootstrap.Modal) {
                const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modal.hide();
            }
        }

        function redirectToAbove1Lakh() {
            // Redirect to above 1 lakh application route
            window.location.href = '{{ route("user.above.1.lakh.application") }}';
        }

        function checkTotalExpensesLimit(showModalOnCross = false) {
            if (!enforceOneLakhCap) return false;

            const totalExpensesInput = document.querySelector('input[name="group_4_total"]');
            const totalExpenses = parseFloat(totalExpensesInput?.value || 0);
            const exceedsLimit = totalExpenses > 100000;

            if (!exceedsLimit) {
                hasShownTotalExpensesLimitModal = false;
                return false;
            }

            if (showModalOnCross && !hasShownTotalExpensesLimitModal) {
                showTotalExpensesErrorModal(totalExpenses);
                hasShownTotalExpensesLimitModal = true;
            }

            return true;
        }

        // Function to calculate row totals
        function calculateRowTotal(rowId) {
            const totalInput = document.querySelector(`input[name="group_${rowId}_total"]`);
            if (!totalInput) return;

            const row = totalInput.closest('tr');
            if (!row) return;

            const inputs = row.querySelectorAll('input[type="number"]:not([readonly])');
            let total = 0;
            inputs.forEach(input => {
                const val = parseFloat(input.value) || 0;
                total += val;
            });

            if (totalInput) {
                totalInput.value = total;
            }
        }

        // Function to calculate Total Expenses column sums
        function calculateTotalExpenses() {
            const table = document.getElementById('yearWiseTable');
            if (!table) return;

            const rows = table.querySelectorAll('tbody tr');
            if (rows.length < 4) return;

            const totalRow = rows[3]; // 4th row (0-indexed)
            const yearInputs = totalRow.querySelectorAll('input[type="number"]:not([name$="_total"])');
            const totalInput = totalRow.querySelector('input[name="group_4_total"]');

            let grandTotal = 0;

            yearInputs.forEach((input, index) => {
                let columnSum = 0;
                // Sum from rows 0,1,2 for this column
                for (let r = 0; r < 3; r++) {
                    const rowInputs = rows[r].querySelectorAll('input[type="number"]:not([readonly])');
                    if (rowInputs[index]) {
                        columnSum += parseFloat(rowInputs[index].value) || 0;
                    }
                }
                input.value = columnSum;
                grandTotal += columnSum;
            });

            if (totalInput) {
                totalInput.value = grandTotal;
            }

            checkTotalExpensesLimit(true);
        }

        // Add event listeners to table inputs for calculating totals
        function addTotalCalculationListeners() {
            const table = document.getElementById('yearWiseTable');
            if (!table) return;

            const inputs = table.querySelectorAll('input[type="number"]:not([readonly])');
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    const name = this.name;
                    const match = name.match(/group_(\d+)_year\d+/);
                    if (match) {
                        const rowId = match[1];
                        calculateRowTotal(rowId);
                        // Also calculate total expenses if any input changes
                        calculateTotalExpenses();
                    }
                });
            });
        }

        // Call after generating table
        // Modify generateTableColumns to add listeners
        const originalGenerateTableColumns = generateTableColumns;
        generateTableColumns = function(years) {
            originalGenerateTableColumns(years);
            // Add listeners after a short delay to ensure DOM is updated
            setTimeout(addTotalCalculationListeners, 100);
        };
    </script>


    <script>
        // Client-side validation for all fields
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');

            // Function to show error
            function showError(fieldId, message) {
                const errorElement = document.getElementById(fieldId + '_error');
                if (errorElement) {
                    errorElement.textContent = message;
                    errorElement.style.display = 'block';
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.classList.add('is-invalid');
                    }
                }
            }

            // Function to hide error
            function hideError(fieldId) {
                const errorElement = document.getElementById(fieldId + '_error');
                if (errorElement) {
                    errorElement.style.display = 'none';
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.classList.remove('is-invalid');
                    }
                }
            }

            // Validate required fields
            function validateRequired(fieldId, message = 'This field is required') {
                const field = document.getElementById(fieldId);
                if (!field || !field.value.trim()) {
                    showError(fieldId, message);
                    return false;
                } else {
                    hideError(fieldId);
                    return true;
                }
            }

            // Validate select fields
            function validateSelect(fieldId, message = 'Please select an option') {
                const field = document.getElementById(fieldId);
                if (!field || !field.value || field.value === '') {
                    showError(fieldId, message);
                    return false;
                } else {
                    hideError(fieldId);
                    return true;
                }
            }

            // Validate radio groups
            function validateRadioGroup(name, message = 'Please select an option') {
                const radios = document.querySelectorAll(`input[name="${name}"]:checked`);
                if (radios.length === 0) {
                    // Find the first radio and show error
                    const firstRadio = document.querySelector(`input[name="${name}"]`);
                    if (firstRadio) {
                        const fieldId = firstRadio.id;
                        showError(fieldId, message);
                    }
                    return false;
                } else {
                    const fieldId = radios[0].id;
                    hideError(fieldId);
                    return true;
                }
            }

            // Validate table fields
            function validateTableFields() {
                const table = document.getElementById('yearWiseTable');
                if (!table) return true;

                const inputs = table.querySelectorAll('input[type="number"]:not([readonly])');
                let isValid = true;

                inputs.forEach(input => {
                    if (!input.value || input.value === '0') {
                        input.classList.add('is-invalid');
                        isValid = false;
                    } else {
                        input.classList.remove('is-invalid');
                    }
                });

                if (!isValid) {
                    // Show a general table error
                    const tableError = document.getElementById('table_error');
                    if (tableError) {
                        tableError.style.display = 'block';
                    }
                } else {
                    const tableError = document.getElementById('table_error');
                    if (tableError) {
                        tableError.style.display = 'none';
                    }
                }

                return isValid;
            }

            form.addEventListener('submit', function(e) {
                let isValid = true;

                // Basic fields
                isValid = isValid && validateSelect('financial_asset_type',
                    'Financial Asset Type is required');
                isValid = isValid && validateSelect('financial_asset_for',
                    'Financial Asset For is required');
                isValid = isValid && validateRequired('course_name', 'Course Name is required');
                isValid = isValid && validateRequired('university_name', 'University Name is required');
                isValid = isValid && validateRequired('college_name', 'College Name is required');
                isValid = isValid && validateRequired('country', 'Country is required');
                isValid = isValid && validateRequired('city_name', 'City Name is required');
                isValid = isValid && validateRequired('start_year', 'Start Year is required');
                isValid = isValid && validateRequired('expected_year',
                    'Expected Year of Completion is required');

                // School fields
                isValid = isValid && validateRequired('school_name', 'School Name is required');
                isValid = isValid && validateRequired('school_board', 'Board is required');
                isValid = isValid && validateRequired('school_completion_year',
                    'Year of Completion is required');
                isValid = isValid && validateRadioGroup('school_grade_system', 'Grade System is required');

                // School grade system
                const percentageRadio = document.getElementById('grade_percentage');
                const cgpaRadio = document.getElementById('grade_cgpa');

                if (percentageRadio && percentageRadio.checked) {
                    isValid = isValid && validateRequired('10th_mark_obtained',
                        'Marks obtained is required');
                    isValid = isValid && validateRequired('10th_mark_out_of', 'Marks out of is required');
                    isValid = isValid && validateRequired('school_percentage', 'Percentage is required');
                } else if (cgpaRadio && cgpaRadio.checked) {
                    isValid = isValid && validateRequired('school_CGPA', 'CGPA is required');
                    isValid = isValid && validateRequired('school_cgpa_out_of', 'CGPA out of is required');
                }

                // JC fields
                isValid = isValid && validateRequired('jc_college_name', 'College Name is required');
                isValid = isValid && validateRequired('jc_stream', 'Stream is required');
                isValid = isValid && validateRequired('jc_board', 'Board is required');
                isValid = isValid && validateRequired('jc_completion_year',
                    'Year of Completion is required');
                isValid = isValid && validateRadioGroup('jc_grade_system', 'Grade System is required');

                // JC grade system
                const jcPercentageRadio = document.getElementById('jc_grade_percentage');
                const jcCgpaRadio = document.getElementById('jc_grade_cgpa');

                if (jcPercentageRadio && jcPercentageRadio.checked) {
                    isValid = isValid && validateRequired('12th_mark_obtained',
                        'Marks obtained is required');
                    isValid = isValid && validateRequired('12th_mark_out_of', 'Marks out of is required');
                    isValid = isValid && validateRequired('jc_percentage', 'Percentage is required');
                } else if (jcCgpaRadio && jcCgpaRadio.checked) {
                    isValid = isValid && validateRequired('jc_CGPA', 'CGPA is required');
                    isValid = isValid && validateRequired('jc_cgpa_out_of', 'CGPA out of is required');
                }

                // Validate Total Expenses - should not be greater than 1 lakh for below category
                if (checkTotalExpensesLimit(true)) {
                    e.preventDefault();
                    return false;
                }

                // Final check
                if (!isValid) {
                    e.preventDefault();
                    return false;
                }
            });


            // Real-time validation on blur
            const requiredFields = [
                'financial_asset_type', 'financial_asset_for', 'course_name', 'university_name',
                'college_name', 'country', 'city_name', 'start_year', 'expected_year',
                'school_name', 'school_board', 'school_completion_year', 'school_grade_system',
                'school_percentage',
                'school_CGPA', 'school_cgpa_out_of', 'jc_college_name', 'jc_stream', 'jc_board',
                'jc_completion_year', 'jc_grade_system', 'jc_percentage', 'jc_CGPA', 'jc_cgpa_out_of',
                'qualifications',
                'qualification_institution', 'qualification_start_year', 'qualification_end_year',
                'have_work_experience', 'organization_name', 'work_profile', 'duration_start_year',
                'duration_end_year', 'work_location_city', 'work_country', 'work_type',
                'mention_your_salary', 'salary_amount', '10th_mark_obtained', '10th_mark_out_of',
                '12th_mark_obtained', '12th_mark_out_of'
            ];

            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.addEventListener('blur', function() {
                        if (field.type === 'select-one') {
                            validateSelect(fieldId);
                        } else {
                            validateRequired(fieldId);
                        }
                    });
                }
            });

            // Table validation on input
            const table = document.getElementById('yearWiseTable');
            if (table) {
                table.addEventListener('input', function(e) {
                    if (e.target.type === 'number') {
                        if (e.target.value && e.target.value !== '0') {
                            e.target.classList.remove('is-invalid');
                        } else {
                            e.target.classList.add('is-invalid');
                        }
                    }
                });
            }
        });
    </script>
    {{-- <script>
        document.addEventListener('DOMContentLoaded', function() {
            toggleSchoolGradeFields();
            toggleJcGradeFields();
        });
    </script> --}}

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const universitySelect = document.getElementById('university_name');
            const collegeSelect = document.getElementById('college_name');
            const courseSelect = document.getElementById('course_name');
            
            // Store all college data with courses
            let allColleges = [];
            
            if (collegeSelect) {
                // Collect all college options with their data
                const originalOptions = collegeSelect.querySelectorAll('option');
                originalOptions.forEach(option => {
                    if (option.value) {
                        let courses = [];
                        try {
                            if (option.dataset.courses) {
                                courses = JSON.parse(option.dataset.courses);
                            }
                        } catch(e) {
                            courses = [];
                        }
                        allColleges.push({
                            value: option.value,
                            text: option.text,
                            university: option.dataset.university || '',
                            courses: courses
                        });
                    }
                });
            }

            // Function to filter colleges by university
            function filterCollegesByUniversity(selectedUniversity, preserveSelection = false) {
                if (!collegeSelect) return;
                
                // Get current selection to preserve if possible
                const currentValue = collegeSelect.value;
                
                // Clear existing options
                collegeSelect.innerHTML = '<option value="" disabled selected>Select College Name</option>';
                
                // Filter and add matching colleges
                allColleges.forEach(college => {
                    if (!selectedUniversity || college.university === selectedUniversity) {
                        const option = document.createElement('option');
                        option.value = college.value;
                        option.textContent = college.text;
                        option.dataset.courses = JSON.stringify(college.courses);
                        option.dataset.university = college.university;
                        collegeSelect.appendChild(option);
                    }
                });

                // If we need to preserve selection and the current value exists in filtered options
                if (preserveSelection && currentValue) {
                    collegeSelect.value = currentValue;
                }
            }

            // Function to filter courses by college
            function filterCoursesByCollege(selectedCollegeValue, preserveSelection = false) {
                if (!courseSelect) return;
                
                // Find the college in our stored data
                const selectedCollege = allColleges.find(c => c.value === selectedCollegeValue);
                
                // If not found in stored data, try to get from current select options
                if (!selectedCollege) {
                    const option = collegeSelect.querySelector('option[value="' + selectedCollegeValue + '"]');
                    if (option && option.dataset.courses) {
                        try {
                            const courses = JSON.parse(option.dataset.courses);
                            populateCourseDropdown(courses, preserveSelection, selectedCollegeValue);
                            return;
                        } catch(e) {}
                    }
                }
                
                if (selectedCollege && selectedCollege.courses && selectedCollege.courses.length > 0) {
                    populateCourseDropdown(selectedCollege.courses, preserveSelection, selectedCollegeValue);
                }
            }

            function populateCourseDropdown(courses, preserveSelection = false, selectedValue = null) {
                const currentValue = courseSelect.value;
                courseSelect.innerHTML = '<option value="" disabled selected>Select Course Name</option>';
                courses.forEach(course => {
                    const option = document.createElement('option');
                    option.value = course;
                    option.textContent = course;
                    courseSelect.appendChild(option);
                });
                
                // Restore selection if needed
                if (preserveSelection && currentValue) {
                    courseSelect.value = currentValue;
                }
            }

            // University change event
            if (universitySelect) {
                universitySelect.addEventListener('change', function() {
                    filterCollegesByUniversity(this.value, false);
                    // Reset course selection
                    if (courseSelect) {
                        courseSelect.innerHTML = '<option value="" disabled selected>Select Course Name</option>';
                    }
                });

                // Initialize on page load - handle saved data
                const selectedUniversity = universitySelect.value;
                const savedCollege = collegeSelect ? collegeSelect.value : '';
                const savedCourse = courseSelect ? courseSelect.value : '';
                
                if (selectedUniversity) {
                    // Filter colleges by university and preserve the saved selection
                    filterCollegesByUniversity(selectedUniversity, true);
                    
                    // If there's a saved college, load its courses
                    if (savedCollege) {
                        filterCoursesByCollege(savedCollege, true);
                    }
                }
            }

            // College change event - populate courses
            if (collegeSelect && courseSelect) {
                collegeSelect.addEventListener('change', function() {
                    filterCoursesByCollege(this.value, false);
                });
            }
        });
    </script>
@endsection
